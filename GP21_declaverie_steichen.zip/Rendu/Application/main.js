//Variables globales
var carte;                  // carte dynamique
var trace;                  // trace au sol
var mode = 1;               // mode : trace / localisation
var marker;                 // marqueur de satellite
var map_displayed = true;   // carte affichée (si faux, tableaux affichés)
var live_interval;          // identifiant d'intervalle pour le déplacement en direct
var coord_label;

// Change entre l'affichage de la carte et des tableaux
function switchDisplay() {
    if(map_displayed) { //carte affichée, on la cache et affiche les tableaux
    
        map_displayed = false;
        document.getElementById('map').style.display = "none";
        document.getElementById('values').style.display = "block";
        document.getElementById('preliminaries').style.display = "block";
        document.getElementById('switch').innerHTML = "Carte dynamique";
        
    } else { //tableaux affichés, on les cache et affiche la carte
    
        map_displayed = true;
        document.getElementById('map').style.display = "block";
        document.getElementById('values').style.display = "none";
        document.getElementById('preliminaries').style.display = "none";
        document.getElementById('switch').innerHTML = "Tableau de valeurs";
        
    }
}

// Vérifie les limites sur la précision pour éviter un temps de calcul trop long
function checkPrecision(input) {
    if( parseInt(input.value) < -10 ){
        input.value = -10;
        alert("Précision demandée trop grande, par sécurité, il a été réduit");
    }
}

// Active/désative la simulation de suivi en direct
function toggleSimulation(checkbox) {
    var checked = checkbox.checked; // Recupération de la valeur
    
    if( checked ){ // Activation du suivi en direct
        live_interval = window.setInterval(function() {
        
            // Ajouter 100ms toutes les 100ms et rafraîchir
            var t = parseFloat(document.querySelectorAll('input[name="t"]')[0].value); //s
            document.querySelectorAll('input[name="t"]')[0].value = (t + 0.1).toFixed(1);
            refresh_mode2();
            
            if(typeof(extend) != "undefined" && !extend) {
                var reset_extend = true;
                extend = true;
            }
            
        }, 100);
    } else {
        window.clearInterval(live_interval);
        live_interval = null;
        if(reset_extend) {
            extend = false;
        }
    }
}



// Calcule un chemin depuis les paramètres orbitaux
function refresh_mode1(resizeMap=true) {

    /* RECUPERATION DES DONNEES */
    var a = parseFloat(document.querySelectorAll('input[name="a"]')[0].value); //Km
    var e = parseFloat(document.querySelectorAll('input[name="e"]')[0].value); //pas d'unité
    var i = parseFloat(document.querySelectorAll('input[name="i"]')[0].value); //deg
    var L_omega = parseFloat(document.querySelectorAll('input[name="L_omega"]')[0].value); //deg
    var omega = parseFloat(document.querySelectorAll('input[name="omega"]')[0].value); //deg
    var mu = parseFloat(document.querySelectorAll('input[name="mu"]')[0].value); //km^3 / s
    var vmax = parseFloat(document.querySelectorAll('input[name="vmax"]')[0].value); //deg
    var vmin = parseFloat(document.querySelectorAll('input[name="vmin"]')[0].value); //deg
    var vstep = parseFloat(document.querySelectorAll('input[name="vstep"]')[0].value); //pas d'unité
    

    // Calculs préliminaires
    Vc = Math.acos(-e); //Anomalie vraie critique, en radians
    Tp = -(Math.sqrt(Math.pow(a, 3) / mu)) * (Math.asin((Math.sqrt(1-Math.pow(e, 2))*Math.sin(-Math.rad(omega)))/(1+(e*Math.cos(-Math.rad(omega))))) - e*((Math.sqrt(1-Math.pow(e, 2))*Math.sin(-Math.rad(omega)))/(1+(e*Math.cos(-Math.rad(omega)))))); //Temps de passage au périgée

    // Retirer les valeurs des tableaux
    var rows = document.querySelectorAll('#values tr');
    for (var k = 0; k < rows.length; k++) {
        if( rows[k].id != "headers" ){
            rows[k].remove();
        }
    }
    var rows = document.querySelectorAll('#preliminaries tr');
    for (var k = 0; k < rows.length; k++) {
        if( rows[k].id != "prelim_headers" ){
            rows[k].remove();
        }
    }
    
    // Ajouter Vc et Tp au tableau
    var row = document.getElementById('preliminaries').insertRow(-1);
    var toAdd = [Vc, Tp];
    for( var k = 0; k < toAdd.length; k++) {
        var cell = row.insertCell(-1);
        cell.innerHTML = toAdd[k].toFixed(4);
    }
    
    // Variable qui contiendra nos coordonnées finales
    var coords = [];
    
    // V est l'anomalie vraie en degrés (position du mobile sur son orbite)
    for( v = vmin; v <= vmax; v += vstep ){
    
            /* CALCUL DE T  (TEMPS DE PASSAGE) */
        // Calcul de correction (x est entre k*k1+k2 et (k+1)*k1+k2)
        var x = Math.rad(v), k1 = 2*Math.PI, k2 = Vc; //données
        var corr1 = 0;  
        if( x > 0 ) {
            while( x > k1-k2 ){
                x -= k1;
                corr1++;
            }
            
            
            corr1 *= 2;
            if( x > k2 ){ corr1 += 1;}	
            
        } else if( x < 0 ){
            while( x < -k1+k2 ){
                x += k1;
                corr1--;
            }                
            
            corr1 *= 2;
            if( x < -k2 ){ corr1 -= 1; }
            
        } else { corr1 = 0; }

        // Calcul de valeur
        var t_inside = Math.asin( (Math.sqrt(1-Math.pow(e, 2))*Math.sin(Math.rad(v)))/1+e*Math.cos(Math.rad(v))) - e * (Math.sqrt(1-Math.pow(e, 2))*Math.sin(Math.rad(v))) / (1+e*Math.cos(Math.rad(v)));
        var t = Math.sqrt(Math.pow(a, 3)/mu) * (corr1*Math.PI + (Math.pow(-1, corr1) * t_inside)) + Tp;

            /* CALCUL DE LA (LATITUDE) */
        La = Math.deg(Math.asin(Math.sin(Math.rad(i))*Math.sin(Math.rad(omega)+Math.rad(v))));
        
        
            /* CALCUL DE LO (LONGITUDE EN TERRE FIXE) */
        // Calcul de correction (x est entre k1+k2b et k1+(k2+1)b)            
        var x = Math.rad(v), k1 = -Math.rad(omega) - Math.rad(90), k2 = Math.rad(180); //données
        var corr2 = 0;                                                                //correction
        
        if( x > k1 ){
            while( x > k1+k2 ){
                x -= k2;
                corr2++;
            }
        } else if( x < k1 ){
            while( x < k1-k2 ){
                x += k2;
                corr2--;
            }
            corr2--;
        } else {
            corr2 = 0;
        }
        
        // Calcul de valeur
        var Lo = undefined;
        var Lo_inside = Math.asin(Math.sin(Math.rad(omega) + Math.rad(v))*(Math.cos(Math.rad(i))/Math.cos(Math.rad(La))))
        if( i < 90 ) { //PROGRADE
            Lo = corr2*Math.PI + (Math.pow(-1, corr2) * Lo_inside)
        } else {       //RETROGRADE
            Lo = -corr2*Math.PI - (Math.pow(-1, corr2) * Lo_inside)
        }
        Lo = Math.deg(Lo);
        
        
            /* CALCUL DE LS (LONGITUDE EN TERRE TOURNANTE) */
        // Calcul de valeur
        Ls = L_omega + Lo - (360/(23*56*60+4))*t;
        
        // Calcul de correction
        while( Ls < -180 ){ Ls += 360 }
        while( Ls > 180 ){ Ls -= 360 }
        
        
            /* VERIFICATION DES VALEURS */
        // La
        if( La > 90 ){
            console.warn("La > 90° (", La, ") pour v = ", v, "°");
        } else if( La < -90 ){
            console.warn("La < 90° (", La, ") pour v = ", v, "°");
        }
        
        // Ls
        if( Ls > 180 ){
            console.warn("Ls > 180° (", Ls, ") pour v = ", v, "°");
        } else if( Ls < -180 ){
            console.warn("Ls < 180° (", Ls, ") pour v = ", v, "°");
        }
       
        // Enregistrement des coordonnées dans notre variable
        coords.push({lat: La, lng: Ls});
        
        // Population du tableau de valeurs
        var row = document.getElementById('values').insertRow(-1);
        var toAdd = [v, t, La, Lo, Ls];
        for( var k = 0; k < toAdd.length; k++) {
            var cell = row.insertCell(-1);
            cell.innerHTML = toAdd[k].toFixed(5);
        }
    }
    
    // Google Maps : définition d'un chemin depuis les coordonnées
    trace.setPath(coords);
    
    // Zoomer/dézoomer la carte pour que toutes les coordonnées soient visibles
    var limites = new google.maps.LatLngBounds();
    for( var i = 0; i < coords.length; i++ ){
        limites.extend(coords[i]);
    }
    if(resizeMap){carte.fitBounds(limites);}
    
    
    
    
    

}

// Calcule la position d'un satellite depuis son temps de passage (en prenant les paramètres orbitaux en compte)
function refresh_mode2() {
    /* RECUPERATION DES DONNEES */
    var t = parseFloat(document.querySelectorAll('input[name="t"]')[0].value); //s
    var a = parseFloat(document.querySelectorAll('input[name="a"]')[0].value); //Km
    var e = parseFloat(document.querySelectorAll('input[name="e"]')[0].value); //pas d'unité
    var i = parseFloat(document.querySelectorAll('input[name="i"]')[0].value); //deg
    var L_omega = parseFloat(document.querySelectorAll('input[name="L_omega"]')[0].value); //deg
    var omega = parseFloat(document.querySelectorAll('input[name="omega"]')[0].value); //deg
    var mu = parseFloat(document.querySelectorAll('input[name="mu"]')[0].value); //km^3 / s
    var vmax = parseFloat(document.querySelectorAll('input[name="vmax"]')[0].value); //deg
    var vmin = parseFloat(document.querySelectorAll('input[name="vmin"]')[0].value); //deg
    var vstep = parseFloat(document.querySelectorAll('input[name="vstep"]')[0].value); //pas d'unité
    var methode = document.querySelectorAll('input[name="res_method"]:checked')[0].value; //méthode de résolution
    var precision = parseInt(document.querySelectorAll('input[name="precision"]')[0].value); //précision
    
    // Choix de la méthode
    if( methode == "Dichotomie" ){
        
        /*
        Par dichotomie, on calcule T pour Vmin, Vmax et Vmed (= moyenne algébrique entre Vmin et Vmax)
        Puis, on compare avec le T recherché et on réduit l'intervalle jusqu'à arriver à une précision suffisante
        */
        
        
        var cur_vmin = vmin;
        var cur_vmax = vmax;
        var cur_vmed = (cur_vmin + cur_vmax)/2
        var extend = false;
        
        // Calculs préliminaires
        Vc = Math.acos(-e); //Anomalie vraie critique, en radians
        Tp = -(Math.sqrt(Math.pow(a, 3) / mu)) * (Math.asin((Math.sqrt(1-Math.pow(e, 2))*Math.sin(-Math.rad(omega)))/(1+(e*Math.cos(-Math.rad(omega))))) - e*((Math.sqrt(1-Math.pow(e, 2))*Math.sin(-Math.rad(omega)))/(1+(e*Math.cos(-Math.rad(omega)))))); //Temps de passage au périgée

        // On boucle jusqu'à avoir la précision souhaitée
        while( Math.abs(cur_vmin - cur_vmax) > Math.pow(10, precision) ){
        
                /* CALCUL DE T  (TEMPS DE PASSAGE) POUR NOTRE VMIN */
            // Calcul de correction
            var x = Math.rad(cur_vmin), k1 = 2*Math.PI, k2 = Vc; //données
            var corr = 0;  
            if( x > 0 ) {
                while( x > k1-k2 ){
                    x -= k1;
                    corr++;
                }
                
                
                corr *= 2;
                if( x > k2 ){ corr += 1;}	
                
            } else if( x < 0 ){
                while( x < -k1+k2 ){
                    x += k1;
                    corr--;
                }                
                
                corr *= 2;
                if( x < -k2 ){ corr -= 1; }
                
            } else { corr = 0; }

            // Calcul de valeur
            var t_inside = Math.asin( (Math.sqrt(1-Math.pow(e, 2))*Math.sin(Math.rad(cur_vmin)))/1+e*Math.cos(Math.rad(cur_vmin))) - e * (Math.sqrt(1-Math.pow(e, 2))*Math.sin(Math.rad(cur_vmin))) / (1+e*Math.cos(Math.rad(cur_vmin)));
            var t_vmin = Math.sqrt(Math.pow(a, 3)/mu) * (corr*Math.PI + (Math.pow(-1, corr) * t_inside)) + Tp;


                /* CALCUL DE T  (TEMPS DE PASSAGE) POUR NOTRE VMAX */
            // Calcul de correction
            var x = Math.rad(cur_vmax), k1 = 2*Math.PI, k2 = Vc; //données
            var corr = 0;  
            if( x > 0 ) {
                while( x > k1-k2 ){
                    x -= k1;
                    corr++;
                }
                
                
                corr *= 2;
                if( x > k2 ){ corr += 1;}	
                
            } else if( x < 0 ){
                while( x < -k1+k2 ){
                    x += k1;
                    corr--;
                }                
                
                corr *= 2;
                if( x < -k2 ){ corr -= 1; }
                
            } else { corr = 0; }

            // Calcul de valeur
            var t_inside = Math.asin( (Math.sqrt(1-Math.pow(e, 2))*Math.sin(Math.rad(cur_vmax)))/1+e*Math.cos(Math.rad(cur_vmax))) - e * (Math.sqrt(1-Math.pow(e, 2))*Math.sin(Math.rad(cur_vmax))) / (1+e*Math.cos(Math.rad(cur_vmax)));
            var t_vmax = Math.sqrt(Math.pow(a, 3)/mu) * (corr*Math.PI + (Math.pow(-1, corr) * t_inside)) + Tp;
            
            
                /* CALCUL DE T  (TEMPS DE PASSAGE) POUR NOTRE VMED */
            // Calcul de correction
            var x = Math.rad(cur_vmed), k1 = 2*Math.PI, k2 = Vc; //données
            var corr = 0;  
            if( x > 0 ) {
                while( x > k1-k2 ){
                    x -= k1;
                    corr++;
                }
                
                
                corr *= 2;
                if( x > k2 ){ corr += 1;}	
                
            } else if( x < 0 ){
                while( x < -k1+k2 ){
                    x += k1;
                    corr--;
                }                
                
                corr *= 2;
                if( x < -k2 ){ corr -= 1; }
                
            } else { corr = 0; }

            // Calcul de valeur
            var t_inside = Math.asin( (Math.sqrt(1-Math.pow(e, 2))*Math.sin(Math.rad(cur_vmed)))/1+e*Math.cos(Math.rad(cur_vmed))) - e * (Math.sqrt(1-Math.pow(e, 2))*Math.sin(Math.rad(cur_vmed))) / (1+e*Math.cos(Math.rad(cur_vmed)));
            var t_vmed = Math.sqrt(Math.pow(a, 3)/mu) * (corr*Math.PI + (Math.pow(-1, corr) * t_inside)) + Tp;
            
            
                /* COMPARAISON AVEC T SOUHAITE, REDUCTION DE L'INTERVALLE */
            if( t_vmin < t && t_vmed > t ){
                cur_vmin = cur_vmin;
                cur_vmax = cur_vmed;
                cur_vmed = (cur_vmax + cur_vmin)/2
            } else if( t_vmax > t && t_vmed < t ){
                cur_vmin = cur_vmed;
                cur_vmax = cur_vmax;
                cur_vmed = (cur_vmax + cur_vmin)/2
            } else {
            
                // T non compris dans l'intervalle, on étend la recherche
                if( extend || confirm("L'intervalle [vmin; vmax] ne contient pas la valeur de t recherchée. Etendre la recherche ?")) {
                    if( t < t_vmin ){
                        cur_vmin -= vstep;
                        document.querySelectorAll('input[name="vmin"]')[0].value = cur_vmin;
                        
                    } else if( t > t_vmax ){
                        cur_vmax += vstep;
                        document.querySelectorAll('input[name="vmax"]')[0].value = cur_vmax;
                        
                    }
                    
                    extend = true;
                } else {
                    return;
                }
            }
            
            

        }
        
        // On rafraîchit la trace du satellite si les paramètres orbitaux ont changé
        refresh_mode1(false);
        
        // On enregistre v pour calculer ses coordonnées
        var v = cur_vmed;
        
        
            /* CALCUL DE LA (LATITUDE) */
        La = Math.deg(Math.asin(Math.sin(Math.rad(i))*Math.sin(Math.rad(omega)+Math.rad(v))));
        
        
            /* CALCUL DE LO (LONGITUDE EN TERRE FIXE) */
        //Calcul de correction (x est entre a+kb et a+(k+1)b)            
        var x = Math.rad(v), k1 = -Math.rad(omega) - Math.rad(90), k2 = Math.rad(180); //données
        var corr = 0                                                                   //correction
        
        if( x > k1 ){
            while( x > k1+k2 ){
                x -= k2;
                corr++;
            }
        } else if( x < k1 ){
            while( x < k1-k2 ){
                x += k2;
                corr--;
            }
            corr--;
        } else {
            corr = 0;
        }
        
        // Calcul de valeur
        var Lo = undefined;
        var Lo_inside = Math.asin(Math.sin(Math.rad(omega) + Math.rad(v))*(Math.cos(Math.rad(i))/Math.cos(Math.rad(La))))
        if( i < 90 ) { //PROGRADE
            Lo =  corr*Math.PI + (Math.pow(-1, corr) * Lo_inside)
        } else {       //RETROGRADE
            Lo = -corr*Math.PI - (Math.pow(-1, corr) * Lo_inside)
        }
        Lo = Math.deg(Lo);
        
        
            /* CALCUL DE LS (LONGITUDE EN TERRE TOURNANTE) */
        // Calcul de valeur
        Ls = L_omega + Lo - (360/(23*56*60+4))*t;
        
        // Calcul de correction
        while( Ls < -180 ){ Ls += 360 }
        while( Ls > 180 ){ Ls -= 360 }
        
        
            /* VERIFICATION DES VALEURS */
        // La
        if( La > 90 ){
            console.warn("La > 90° (", La, ") pour v = ", v, "°");
        } else if( La < -90 ){
            console.warn("La < 90° (", La, ") pour v = ", v, "°");
        }
        
        // Ls
        if( Ls > 180 ){
            console.warn("Ls > 180° (", Ls, ") pour v = ", v, "°");
        } else if( Ls < -180 ){
            console.warn("Ls < 180° (", Ls, ") pour v = ", v, "°");
        }
        
        // Affichage du marqueur
        if(!marker.getMap()){ marker.setMap(carte) }
        marker.setPosition({lat: La, lng: Ls})
        marker.setTitle("("+La.toFixed(2)+"; "+Ls.toFixed(2)+")")
        
        // Affichage du couple de coordonnées
        coord_label.set('text',  '     ('+La.toFixed(2)+'; '+Ls.toFixed(2)+")");
        
        // Activer la possibilité de simulation de direct
        document.querySelectorAll('input[name="simulate_live"]')[0].removeAttribute("disabled");
        
    } else if( methode == "Calcul direct" ){
        /* SOLUTION MATHEMATIQUE NON TROUVEE */
    }
}

// Changement de mode, trace au sol / localisation
function chgMode() {
    if( mode == 1 ){
        // mode précédent : trace au sol
    
        var inputs_1 = document.querySelectorAll('.mode_1')
        var inputs_2 = document.querySelectorAll('.mode_2')
        for( var i = 0; i < inputs_1.length; i++ ){
            inputs_1[i].style.display = "none"
        }
        for( var i = 0; i < inputs_2.length; i++ ){
            inputs_2[i].style.display = "inline-block";
        }
        mode = 2;
        
    }else if( mode == 2){
        //mode précédent : localisation
        
        var inputs_1 = document.querySelectorAll('.mode_1')
        var inputs_2 = document.querySelectorAll('.mode_2')
        for( var i = 0; i < inputs_2.length; i++ ){
            inputs_2[i].style.display = "none"
        }
        for( var i = 0; i < inputs_1.length; i++ ){
            inputs_1[i].style.display = "inline-block";
        }
        mode = 1;
    }else{
        // mode précédent : indéterminé
        
        mode=1;
        chgMode();
    }
}

// Initialization de la carte dynamique
function initMap() {
    
    // Vérification de la connexion à Internet
    if(!navigator.onLine) {
    
       switchDisplay();
       document.getElementById("switch").style.display = "none";
       document.getElementById("map").style.display = "none";
       setTimeout(function(){alert("La connexion à l'API Google Maps a échoué, veuillez vérifier votre connexion à Internet")}, 100);
    }
    
    // Vérification du type de navigateur
    var electron = false;
    if( typeof(require) != "undefined" ) {
        console.log("here");
        var remote = require('electron').remote;     
        if(remote.getGlobal('electron').inEngine) {
            electron = true
        }  
    }
    if(!(window.chrome || electron)) {
    
        alert("Il est recommand\351 d'utiliser la derni\350re version du navigateur Chrome. Aucun test n'a \351t\351 fait sur les autres navigateurs et l'aspect de la page peut \352tre grandement alt\351r\351e");
    }
    
    //  Affichage de la carte
    carte = new google.maps.Map(document.getElementById('map'), {
        center: {lat: 48.8534100, lng: 2.3488000},
        zoom: 3
      });
      
    // Paramétrage de la trace
    trace = new google.maps.Polyline({
        map: carte,
        geodesic: true,
        strokeColor: '#FF0000',
        strokeOpacity: 1.0,
        strokeWeight: 2
    });
    
    // Paramétrage du marqueur
    marker = new SlidingMarker({
        map: carte,
        draggable: false,
        animation: google.maps.Animation.DROP,
        icon: {
            url: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAZCAMAAADzN3VRAAACT1BMVEUAAAAIHzIIITUJIzkNRXQQPWQSSHUTSXcTSnkXWJAaZKQcbrMdcLYdcbhXjLd0qNJ3qtT5sjP6wVwJIzkTSnn5sjP6wVwJIzkTSnkPPWMSSHUlZ54+d6b5sjP6wVwJIzkTSnkRQmsZYJ3bsWDcoTQJIzkTSnkcbbFsoMoFIDkJIzkTSnn5sjP6wVwJIzkQSHkTSnn5sjP6wVwJIzkTSnn5sjP6wVwJIzkTSnn5sjP6wVwJIzkTSnkPa7gSR3Qfd8J+sdsfeMMhgNB8st6OveQSR3QcbrMMJTkMJTodcbh3qtQTSnoecrkWTHkXTHkbb7Z3qdP5sjP6wVz4sTP5wFwNaLUOabURRHASRXD5sjP6wVz5sjP6wVwPRHINQ3EHHTAIHTD5sjP6wVwIHzMIIDQRRnQRR3QJIzkTSnkJIzkTSnn5sjP6wVwJIzkTSnkJIzkTSnn5sjP6wVwJIzoTSnoTS3r5sjP6wVz5sjP6wVwTSnodcbgecrh3qtQJIzkTSnn5sjP6wVwaZKQdcrlZl8t4q9T5sjP6wVwTSXcbb7cdcbh3qtQJIzkTSnkdcLZzqNN0qNMJIzkTSnkWbbYYYqJenM99rtYJIzkPRHITSnkYbrYZb7d7rNX5sjP6wVwJIzkTSnkJIjgJIzkJIzoNME8NNFURSnoTSHUTSXgTSnkWU4cWWpUYXZgZX5wZb7cab7gacLgbaqwbcLgbcrwccLgedLwfcLUidbsjXY8xfr9KjcZMkMlPkspvo854q9R7rNV7rdZ8rdaBsdj5sjP6wVyvH4eoAAAAoXRSTlMAAAAAAAAAAAAAAAAAAAAAAAAAAQEBAQMDBAQEBAQEBQUGBgYGCwsLCwwMDA4ODw8PDw8YGB4eMDAxMTg4Ozs7Oz4+Pj5JSUpKSkpLS1RUVVVXV2ZmhYWFhYqKkZGUlZaWmJiampqavLy9vb29vr7GxsbGycnJ19fc3N3d5OTp6ezs7u7u7u/v8vLy8vb2+vr6+/v8/Pz8/f39/f39/f3+/uAQafIAAAHfSURBVBgZBcGFY9RlAADQhwfyQ0DiDjZiIzdwozsVEOlWQLrjjm7FAhQwNrrrjg9FPpBUidHc/WG8R8aIIcoB6FM8smgobWSMqd9eK5MkgIolm4pX58KYn2LMVUsSoB1G7i3OZUR9PFWIW7vKAAYeWKVi79WhhmyPhUKMuWrltGxOzx3Fb4wsLqI2F2MhxlytDz8CviyusumIctVbYyxcjBsHoDtTPrHjgCVFMrrm4sVCjLs7mfHdpBU3Jus5UEUfkkR1LsZ4a72xv/3/8M+V0A6SJKN2Y7x1Z8HEX55cvvv3FwBQbsCedfOfHX939p8LcX83TQForLPPT7x6++LMzV+nkwDwMeMOv33dcP/fQ5/SBIDWTPvj9bmGe/8dm6CDDwBopfcPb640nH5w7PbXa3f1UwYAc14+v3Tv5/EL/7oeNtRIp1LQHpY9ffzo98+suR5CyFZJpehbaVAPs+Ly2d9P1XFXCPnzIdtFmtJSB3fqP5Ne6LchnM+HsKVKmaObrS59BTRrpCYbQj6EbA2LS6N8W9rZgxYtKVOVDSGfD9sGG3ZtX6XVBwcB0rpsCfmToW4480r7RqE9kEqpyobw42iYd620eWklIJVKq9lWN1paW4YtPlrqC0CZwcOlvQdo6pWZvA81+gAAAABJRU5ErkJggg==",
            size: new google.maps.Size(25, 25),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(12.5, 12.5)
        }
      });
      
      // Paramétrage du texte de coordonnées
      coord_label = new MapLabel({
        map: carte,
        fontSize: 13,
        align: 'left'
      });
      coord_label.bindTo('position', marker);
      
      
    
    // Affichage des ombres jour/nuit, mise à jour toutes les 10 secondes
    nite.init(carte)
    window.setInterval(function() { nite.refresh() }, 10000);
    
    // Rafraîchir la trace
    refresh_mode1()
}


// Fonctions mathématiques
Math.rad = function(degrees) {
  return degrees * Math.PI / 180;
};
Math.deg = function(radians) {
  return radians * 180 / Math.PI;
};


// Appel de la fonction d'initialisation
initMap();
